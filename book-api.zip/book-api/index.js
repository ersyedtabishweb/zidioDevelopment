const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// In-memory book storage
let books = [];

app.get('/', (req, res) => {
  res.send('Welcome to the Book API!');
});

// GET all books
app.get('/books', (req, res) => {
  res.json(books);
});

// POST a new book
app.post('/books', (req, res) => {
  const book = req.body;
  books.push(book);
  res.status(201).json(book);
});

// PUT (update) a book by ID
app.put('/books/:id', (req, res) => {
  const id = req.params.id;
  const updatedBook = req.body;

  let index = books.findIndex(book => book.id === id);

  if (index !== -1) {
    books[index] = updatedBook;
    res.json(updatedBook);
  } else {
    res.status(404).json({ message: 'Book not found' });
  }
});

// DELETE a book by ID
app.delete('/books/:id', (req, res) => {
  const id = req.params.id;
  books = books.filter(book => book.id !== id);
  res.json({ message: 'Book deleted' });
});

app.listen(port, () => {
  console.log(`✅ Server is running on http://localhost:${port}`);
});