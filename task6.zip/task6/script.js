// Select form and error/success elements
const form = document.getElementById('contactForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const messageInput = document.getElementById('message');

const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const messageError = document.getElementById('messageError');
const successMsg = document.getElementById('successMsg');

// Form submit event
form.addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent form submission

  // Reset previous messages
  nameError.textContent = '';
  emailError.textContent = '';
  messageError.textContent = '';
  successMsg.textContent = '';

  let isValid = true;

  // Validate Name
  if(nameInput.value.trim() === '') {
    nameError.textContent = 'Please enter your name';
    isValid = false;
  }

  // Validate Email
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if(emailInput.value.trim() === '') {
    emailError.textContent = 'Please enter your email';
    isValid = false;
  } else if(!emailInput.value.match(emailPattern)) {
    emailError.textContent = 'Please enter a valid email';
    isValid = false;
  }

  // Validate Message
  if(messageInput.value.trim() === '') {
    messageError.textContent = 'Please enter your message';
    isValid = false;
  }

  // If all valid, show success message
  if(isValid) {
    successMsg.textContent = 'Form submitted successfully!';
    form.reset(); // Optional: clear form fields
  }
});