document.getElementById("loadUsers").addEventListener("click", fetchUsers);

function fetchUsers() {
  fetch("https://jsonplaceholder.typicode.com/users")
    .then(response => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then(data => displayUsers(data))
    .catch(error => {
      console.error("Error fetching data:", error);
    });
}

function displayUsers(users) {
  const container = document.getElementById("userContainer");
  container.innerHTML = ""; // Clear old data

  users.forEach(user => {
    const card = document.createElement("div");
    card.classList.add("user-card");

    card.innerHTML = `
      <h3>${user.name}</h3>
      <p><strong>Username:</strong> ${user.username}</p>
      <p><strong>Email:</strong> ${user.email}</p>
      <p><strong>Phone:</strong> ${user.phone}</p>
      <p><strong>Website:</strong> <a href="http://${user.website}" target="_blank">${user.website}</a></p>
      <p><strong>City:</strong> ${user.address.city}</p>
    `;

    container.appendChild(card);
  });
}